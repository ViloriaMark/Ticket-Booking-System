# Mh Ticket Booking System
* The project is aimed to make a Online Ticket Booking Portal that can any Citizen use to book tickets [Both Train and Bus] online and their data can be maintain computerized on AWS Server.
* This system can be used for Ticket Booking in Maharastra.

## TECH/FRAMEWORK USED:
* HTML
* CSS
* Javascript
* PHP
* Xampp Server
* MySQL
## This are some Outputs of the Project:
![image](https://user-images.githubusercontent.com/60505090/130497323-73866e5d-03a7-4c02-acdc-978610355256.png)
![image](https://user-images.githubusercontent.com/60505090/130501867-11b7e94b-208e-49af-b0da-4c18e7800190.png)
![image](https://user-images.githubusercontent.com/60505090/130501947-6a7a9414-ccc0-4a00-8f9f-af4cf69bc615.png)
![image](https://user-images.githubusercontent.com/60505090/130502025-c43a6356-beeb-42aa-b84c-697d03df672d.png)
![image](https://user-images.githubusercontent.com/60505090/130502063-573a1fab-f60e-4016-9645-8cf22e1c467a.png)
![image](https://user-images.githubusercontent.com/60505090/130502106-08e3d1a2-06ca-478d-8809-9c71dbadc3ce.png)

